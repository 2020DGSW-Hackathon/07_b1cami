package dgsw.b1cami.cocode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CocodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
