package dgsw.b1cami.cocode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CocodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CocodeApplication.class, args);
	}

}
