import 'package:flutter/material.dart';

const Color white = Colors.white;
const Color mainColor = Color.fromARGB(0xff, 161, 206, 255);
const Color black = Colors.black;
