package com.example.cocode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
