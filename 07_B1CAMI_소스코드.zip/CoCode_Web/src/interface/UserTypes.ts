export default interface IUserTypes {
	email?: string;
	name?: string;
	id?: number;
	certifyCode?: string | null;
	password?: string;
	schoolNumber?: number | null;
}
