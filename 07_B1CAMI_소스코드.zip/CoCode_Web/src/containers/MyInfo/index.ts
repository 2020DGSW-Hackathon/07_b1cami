export { default } from './MyInfoContainer';
