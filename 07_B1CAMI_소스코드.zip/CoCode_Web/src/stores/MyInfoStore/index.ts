export { default } from './MyInfoStore';
