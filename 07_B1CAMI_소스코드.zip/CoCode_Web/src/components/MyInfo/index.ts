export { default } from "./MyInfo";
