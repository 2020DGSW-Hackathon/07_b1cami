export { default } from "./Meal";
