import React from "react";
import "./Home.scss";

interface HomeProps {

}

const Home = ({}: HomeProps) => {
  return (
    <>
      <div></div>
    </>
  );
};

export default Home;
