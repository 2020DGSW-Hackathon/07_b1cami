export { default } from './PageTemplate';
