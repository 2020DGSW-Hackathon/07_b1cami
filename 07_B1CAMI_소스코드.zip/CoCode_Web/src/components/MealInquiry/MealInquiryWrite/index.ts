export { default } from "./MealInquiryWrite";
