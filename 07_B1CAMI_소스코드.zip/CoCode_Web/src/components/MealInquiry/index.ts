export { default } from "./MealInquiry";
