export { default } from "./MealInquiryModal";
